<?php
/* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    Controlleur gérant l'ajout d'un covoiturage
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| */
namespace App\Controllers\users;

use App\Controllers\subControllers\GpsLogicsController;

use App\models\users\UserModel;
use App\models\users\CarsModel;
use App\models\users\UserCarpoolsModel;
use App\models\users\SubmitCarpoolModel;


class UserCarpoolController {
    
    protected Array $errors = [];
    protected string $success = '';

    // Foncion gérant l'affichage des infos de covoiturage d'un utilisateur
    public function usercarpoolArea() {
        

        $user = UserModel::getUserById($_SESSION['user_id']);
        $cars = CarsModel::getUserCars($user['id']);

        // Si le formulaire est soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // On récupère toutes les infos
            $date = $_POST['date'];
            $departureTime = strtotime($_POST['departure-time']);
            $departureCity = htmlspecialchars($_POST['departure-city']);
            $arrivalTime = strtotime($_POST['arrival-time']);
            $arrivalCity = htmlspecialchars($_POST['arrival-city']);
            $status = 'Planifié';
            $seats = intval($_POST['nb-seats']);
            $availableSeats = intval($_POST['nb-seats']);
            $price = floatval($_POST['price']);
            $driverId = $_SESSION['user_id'];
            $carId = intval($_POST['car-id']);
            $isEcological = 0;
            $smoke = isset($_POST['smoke']) ? 1 : 0;
            $animals = isset($_POST['animals']) ? 1 : 0;
            $preferences = htmlspecialchars($_POST['preferences'] ?? '');
            $commission = 0;

            $tomorrow = date("Y-m-d", strtotime("+1 day"));
            if ($date < $tomorrow) {
                $this->errors[] = 'Vous ne pouvez soumettre de covoiturage pour une date antérieure au ' . date('d-m-Y', strtotime("+2 day"));
            }

            // On évite les durées négatives
            if ($departureTime >= $arrivalTime) {
                $arrivalTime = strtotime('+1 day', $arrivalTime);
            }
            
            $duration = ($arrivalTime - $departureTime) / 60;
            

            // On vérifie que l'utilisateur a bien des véhicules enregistrés
            if (count($cars) === 0) {
                $this->errors[] = 'Vous ne pouvez pas soumettre de covoiturage sans avoir renseigné de véhicule.';
            } else {
                // On récupère son véhicule
                $car = CarsModel::getOneCar($driverId, $carId);

                // On s'assure que le véhicule appartient à l'utilisateur
                if (!$car) {
                    $this->errors[] = 'Le véhicule ne vous est pas rattaché.';
                }

                // On configure $isEcological si le moteur est électrique
                if (strtolower($car['energy']) == 'electrique') {
                    $isEcological = 1;
                }
            }
        
            // Si pas d'erreurs, on continue
            if(empty($this->errors)) {
                
                $gpsLogics = new GpsLogicsController();
                // On appelle la fonction pour récupérer les coordonnées GPS des villes
                $departureCoordinates = $gpsLogics->getCoordinates($departureCity);
                $arrivalCoordinates = $gpsLogics->getCoordinates($arrivalCity);
                if (count($departureCoordinates) === 0 || count($arrivalCoordinates) === 0) {
                    if (count($departureCoordinates) === 0 && count($arrivalCoordinates) === 0) {
                        $this->errors[] = 'Erreur de récupération des coordonnées des villes.';
                    } elseif (count($departureCoordinates) === 0) {
                        $this->errors[] = 'Erreur de récupération des coordonnées de la ville de départ.';
                    } else {
                        $this->errors[] = 'Erreur de récupération des coordonnées de la ville d\'arrivée.';
                    }
                }
            }

            // Si pas d'erreurs, on crée le covoiturage
            if(empty($this->errors)) {
                $submitCarpool = SubmitCarpoolModel::addCarpool(
                    $date,
                    date('H:i', $departureTime),
                    $departureCity,
                    $departureCoordinates['postalcode'],
                    $departureCoordinates['lon'],
                    $departureCoordinates['lat'],
                    date('H:i', $arrivalTime),
                    $arrivalCity,
                    $arrivalCoordinates['postalcode'],
                    $arrivalCoordinates['lon'],
                    $arrivalCoordinates['lat'],
                    $duration,
                    $status,
                    $seats,
                    $availableSeats,
                    $price,
                    $driverId,
                    $carId,
                    $isEcological,
                    $smoke,
                    $animals,
                    $preferences
                );
                
                if ($submitCarpool) {
                    $this->success = 'Covoiturage soumis avec succès !';
                } else {
                    $this->errors[] = 'Erreur lors de la soumission du covoiturage.';
                }
            }

            if(empty($this->errors)) {
                $addDriver = SubmitCarpoolModel::addDriver($user['id'], $submitCarpool);
            }

        }

        // On récupère les covoiturages
        $carpools = UserCarpoolsModel::getCarpoolsByUserId($user['id']);
        $errors = $this->errors;
        $success = $this->success;
        require_once ROOT_PATH . 'src/Views/users/submitCarpoolView.php';
    }
}