<?php
/* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    Controlleur gérant la recherche de covoiturages
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| */
namespace App\Controllers;

use App\Controllers\subControllers\SearchMethodsController;
use App\Controllers\subControllers\GpsLogicsController;


class CarpoolSearchController {

    protected array $errors = [];

    public function CarpoolSearchArea() {

        $results = [];
        $suggestion = false;
        $research = false;      // Permet de savoir si une recherche est lancée

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $research = true;

            $departureCity = htmlspecialchars($_POST['departure-city']);
            $arrivalCity = htmlspecialchars($_POST['arrival-city']);
            $date = $_POST['date'];
            $radius = 20; // Valeur par défaut
            if (isset($_POST['radius'])) {
                if (intval($_POST['radius']) !== 0) {
                    $radius = intval($_POST['radius']);
                } else {
                    $radius = 1;
                }
            }
            print_r($radius);

            // On s'assure d'avoir tous les champs
            if (!isset($departureCity) || !isset($arrivalCity) || !isset($date)) {
                $this->errors[] = 'Il est nécessaire de renseigner les lieux et la date.';
            }

            // On appelle le controller gps
            $gpsLogics = new GpsLogicsController;

            // On essaye de récupérer les coordonnées des villes
            $departureCoordinates = $gpsLogics->getCoordinates($departureCity);
            if ($departureCoordinates === null) {
                $this->errors[] = 'Ville de départ introuvable.';
            }  
            $arrivalCoordinates = $gpsLogics->getCoordinates($arrivalCity);
            if ($arrivalCoordinates === null) {
                $this->errors[] = 'Ville d\'arrivée introuvable.';
            }
            // S'il y a eu une erreur, on arrête ...
            if (!empty($this->errors)) {
                $errors = $this->errors;
                require_once ROOT_PATH . 'src/Views/users/carpoolsSearchView.php';
                return;
            }
            
            // Sinon, on ajoute les coordonnées aux tableaux
            $departure = array_merge(['city' => $departureCity], $departureCoordinates);
            $arrival = array_merge(['city' => $arrivalCity], $arrivalCoordinates);
            //Et on appelle la methode de recherche par coordonnées
            $searchMethods = new SearchMethodsController;
            // Et on stocke son contenu dans $carpools
            $results = $searchMethods->coordinatesSearch($departure, $arrival, $date, $radius);

            
            if (isset($results['suggestion'])) {
                $suggestion = true;
                unset($results['suggestion']);
            }
            
        }
        
        $errors = $this->errors;
        require_once ROOT_PATH . 'src/Views/carpoolSearchView.php';

    }
}