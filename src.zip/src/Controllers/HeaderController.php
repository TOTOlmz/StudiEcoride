<?php
/* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    Contrôleur gérant l'affichage de l'entête
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| */

namespace App\Controllers;

class HeaderController {
    
    public function header() {
        $connected = false;
        $staff = false;

        // On vérifie si une session est en cours
        if (isset($_SESSION['user_id'])) {
            $connected = true;
            // On vérifie si l'utilisateur est de l'entreprise
            if ($_SESSION['user_role'] !== 'USER') {
                $staff = true;
            }
        }

        // On charge la vue
        require ROOT_PATH . '/src/Views/headerView.php';
    }
}